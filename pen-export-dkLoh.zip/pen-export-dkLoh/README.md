# Coming Soon landing page

A Pen created on CodePen.io. Original URL: [https://codepen.io/jermbo/pen/dkLoh](https://codepen.io/jermbo/pen/dkLoh).

Wanted to build a neat coming soon page for my site. This is the result. Check out CosmicStrawberry.com for the same thing :P